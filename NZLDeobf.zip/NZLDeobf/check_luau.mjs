import fs from 'fs';
const { Lua } = await import('@luau-rs/luau');
const lua = await Lua.create();
const src = fs.readFileSync('nzl_obf.lua','utf8');
try { const bc = lua.compile(src); console.log('COMPILE OK, bytecode bytes:', bc.length); }
catch(e){ console.log('COMPILE FAIL:', (e.message ?? String(e)).split('\n').slice(0,4).join(' | ')); }
const repro = 'local a=1\nwhile true do\nif a<=202 then\nlocal function getChar()\na=30322\nelse\nreturn\nend\nend\nend';
try { lua.compile(repro); console.log('REPRO COMPILES: OK'); }
catch(e){ console.log('REPRO FAIL:', (e.message??String(e)).split('\n')[0]); }
