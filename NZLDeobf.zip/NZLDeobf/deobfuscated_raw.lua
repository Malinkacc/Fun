-- NZL Studio Obfuscator — статическая деобфускация (NZLDeobf/deobf.mjs)
-- ВНИМАНИЕ: обфусцированный оригинал (nzl_obf.lua) вообще не компилируется
-- (101 ошибка парсинга Luau) — обфускатор разрезал инструкции на синтаксически
-- невалидные фрагменты и повредил диспетчер (дублирующиеся границы состояний).
-- Ниже — восстановленный порядок фрагментов по переходам стейт-машины
-- (все переходы вычислены статически, рантайм не требуется).
-- states: entry=20029, chained=835/907
local D1=Tabs.Dgn:AddLeftGroupbox("Dungeons");
pcall(function ()
F1:AddToggle("OreFarm",{Text="Enabled"}):OnChanged(function ()
end)
{"Ring of Fire","RingOfFire"},;
ijC=UIS.JumpRequest:Connect(function ()
Text="WalkSpeed",;
C3:AddButton({Text="Hunt Boss",Func=bossHunt});
if Toggles.FlyEnabled.Value then ;startFly(); else ;stopFly(); end ;
end)
if not o then ;return nil; end ;
M3:AddButton({Text="Server Hop",Func=srvHop});
notify("Search...",2);
Text="Refresh",;
local hrp=getHRP();
end
local function notify(t,d)
end
Text="JumpPower",;
SaveManager:SetIgnoreIndexes({"MenuKeybind"});
local C3=Tabs.Combat:AddRightGroupbox("Other");
if #c==0 then ;notify("None",2);return ; end ;
local Library=loadstring(game:HttpGet(repo .. "Library.lua"))();
bb.Size=UDim2.new(0,220,0,50);
local c=getChar();
local hrp=getHRP();
if not hrp then ;return ; end ;
for _,m in ipairs(mobs) do ;task.spawn(function ();pcall(function ();rf:InvokeServer("shoot",{hrp.Position,m.Pos}); end)
end)
rf:InvokeServer(cfg.method,fa);
return LP.Character;
Min=10,;
local V2=Tabs.ESP:AddRightGroupbox("Visual");
lbl.Text="FPS:--";
end
if #n>0 then ;Options.BT:SetValues(n);Options.BT:SetValue(n[1]); end ;
ThemeManager:ApplyToTab(Tabs.Settings);
C1:AddSlider("KAR",{
local function getMobNames()
if UIS:IsKeyDown(Enum.KeyCode.Space) then ;d=d+Vector3.new(0,1,0); end ;
freeze(Toggles.Freeze.Value);
table.sort(c,function (a,b)
end
notify("Equipped: " .. name,2);
MV1:AddToggle("Freeze",{Text="Freeze"}):OnChanged(function ()
Default=0.05,;
end
end)
local c=findPlayerPortal();
if #c==0 then ;notify("No portal",3);return ; end ;
task.spawn(function ()
local b=WS:FindFirstChild("Bases");
Options=nil;
for _,m in ipairs(mobs) do ;if m.Obj and m.Obj.Parent and m.Hum.Health>0 then ;realInstakillMob(m); end ; end ;
local MV1=Tabs.Move:AddLeftGroupbox("Movement");
task.spawn(function ()
end
local function equipAll()
while true do ;task.wait(1);clearESP();local hrp=getHRP();if not hrp then ;continue; end ;local d=(Toggles and Toggles.UnlimitedRange and Toggles.UnlimitedRange.Value) and math.huge or ((Options and Options.ESPD and Options.ESPD.Value) or 5000);if Toggles and Toggles.MobESP and Toggles.MobESP.Value then ;for _,m in ipairs(getMobs(false)) do ;local dst=(hrp.Position-m.Pos).Magnitude;if dst<=d then ;mkESP(m.Part,{;text=(isBoss(m) and "👑 " or "💀 ").. m.Name .. "\n" .. math.floor(m.Hum.Health).. "/" .. math.floor(m.MaxHp).. "[" .. math.floor(dst).. "m]",;color=isBoss(m) and Color3.fromRGB(255,20,20) or Color3.fromRGB(255,100,100);}); end ; end ; end ;if Toggles and Toggles.CompESP and Toggles.CompESP.Value then ;for _,m in ipairs(getMobs(true)) do ;if m.IsComp then ;local dst=(hrp.Position-m.Pos).Magnitude;if dst<=d then ;mkESP(m.Part,{;text="🐾 " .. m.Name .. "\n" .. math.floor(m.Hum.Health),;color=Color3.fromRGB(100,255,150);}); end ; end ; end ; end ;if Toggles and Toggles.OreESP and Toggles.OreESP.Value then ;for _,o in ipairs(getOres()) do ;local dst=(hrp.Position-o.Pos).Magnitude;if dst<=d then ;mkESP(o.Part,{;text="⛏ " .. o.Name .. "[" .. math.floor(dst).. "m]",;color=Color3.fromRGB(200,200,100);}); end ; end ; end ;if Toggles and Toggles.PlrESP and Toggles.PlrESP.Value then ;for _,p in ipairs(Players:GetPlayers()) do ;if p~=LP and p.Character then ;local pr=p.Character:FindFirstChild("HumanoidRootPart");local h=p.Character:FindFirstChildOfClass("Humanoid");if pr and h then ;local dst=(hrp.Position-pr.Position).Magnitude;if dst<=d then ;mkESP(pr,{;text="👤 " .. p.Name .. "\n" .. math.floor(h.Health),;color=Color3.fromRGB(100,200,255);}); end ; end ; end ; end ; end ; end ;
if Toggles and Toggles.AntiAFK and Toggles.AntiAFK.Value then ;pcall(function ();local vu=game:GetService("VirtualUser");vu:CaptureController();vu:ClickButton2(Vector2.new()); end)
local M3=Tabs.Main:AddRightGroupbox("Actions");
end
if not tool then ;return false; end ;
local function stopFly()
task.spawn(function ()
notify("🔫 Trepid Multi-Target Shoot!",4);
local killed=0;
local F1=Tabs.Farm:AddLeftGroupbox("Ore Farm");
Options.MobT:SetValues(getMobNames());
Text="Check Items",;
}
Default=100,;
if p and p.Character then ;local pr=p.Character:FindFirstChild("HumanoidRootPart");if pr then ;tpA(pr.Position,3); end ; end ;
MV2:AddSlider("FS",{
Main=Window:AddTab("Main"),;
end
if Toggles and Toggles.AntiDeath and Toggles.AntiDeath.Value and savedPos then ;task.wait(1.5);local h=c:WaitForChild("HumanoidRootPart",5);if h then ;h.CFrame=savedPos; end ; end ;
local cam=WS.CurrentCamera;
if #n>0 then ;Options.EquipItem:SetValues(n);Options.EquipItem:SetValue(n[1]); end ;
while true do ;local interval=(Options and Options.AutoIKSpeed and Options.AutoIKSpeed.Value) or 0.1;task.wait(interval);if Toggles and Toggles.AutoInstakill and Toggles.AutoInstakill.Value then ;local hrp=getHRP();if hrp then ;local radius=(Options and Options.AutoIKRadius and Options.AutoIKRadius.Value) or 500;for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=radius and m.Hum.Health>0 then ;task.spawn(function ();attackWithAllWeapons(m); end); end ; end ; end ; end
Text="Refresh",;
while true do ;local speed=(Options and Options.KASpeed and Options.KASpeed.Value) or 0.05;task.wait(speed);if not (Toggles and Toggles.KillAura and Toggles.KillAura.Value) then ;continue; end ;local hrp=getHRP();if not hrp then ;continue; end ;local r=(Options and Options.KAR and Options.KAR.Value) or 100;for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=r and m.Hum.Health>0 then ;local tool=getEquipped();if tool then ;task.spawn(function ();realWeaponAttack(tool,m); end); end ;if not (Toggles and Toggles.KillAuraAggressive and Toggles.KillAuraAggressive.Value) then ;break; end ; end ; end
args={148,2,-1},;
pcall(function ()
if WEAPON_EXTRAS[tool.Name] then ;pcall(function ();WEAPON_EXTRAS[tool.Name](rf,mob); end)
if not charTool then ;return false; end ;
if not p or not p.Parent then ;return ; end ;
if Library and Library.Unload then ;Library:Unload(); end ;
Func=function ()
local good={};
end)
end
end
Rounding=2;
local h=getHRP();
return a<b;
Text="Radius",;
local mfTarget=nil;
local function getOreTypes()
end
C2:AddSlider("AutoIKSpeed",{
Text="TP",;
local ThemeManager=loadstring(game:HttpGet(repo .. "addons/ThemeManager.lua"))();
notify(table.concat(l,","),6);
if Toggles and Toggles.MaxZoom and Toggles.MaxZoom.Value then ;LP.CameraMaxZoomDistance=10000;LP.CameraMinZoomDistance=0.5; end ;
task.spawn(function ()
if m then ;mfTarget=m;local start=tick();while Toggles.MobFarm and Toggles.MobFarm.Value and m.Obj and m.Obj.Parent and m.Hum and m.Hum.Health>0 do ;attackWithAllWeapons(m);task.wait(0.15);if tick()-start>60 then ;break; end ; end ;mfTarget=nil; end ;
end
end
local arm=mob.Obj:FindFirstChild("Armored");
end
Title="BCW Hub v19 | RCtrl",;
local n={};
t.Font=Enum.Font.GothamBold;
if not rf then ;return false; end ;
if UIS:IsKeyDown(Enum.KeyCode.W) then ;d=d+cam.CFrame.LookVector; end ;
})
Text="Distance",;
if not c then ;return nil; end ;
Text="Refresh",;
pcall(function ()
local function killAllInMap()
})
local hrp=getHRP();
for _,d in ipairs(WS:GetDescendants()) do ;if d:IsA("ParticleEmitter") or d:IsA("Trail") or d:IsA("Beam") or d:IsA("Smoke") or d:IsA("Fire") or d:IsA("Sparkles") then ;pcall(function ();d.Enabled=false; end); end
fps.ResetOnSpawn=false;
local lbl=Instance.new("TextLabel",fps);
local l={};
end)
end
local m=f[1];
if Toggles.NoClip.Value then ;startNC(); else ;stopNC(); end ;
if not hrp or not torso then ;return false; end ;
if h then ;pcall(function ();h.Anchored=s;if s then ;h.AssemblyLinearVelocity=Vector3.zero; end ; end)
table.insert(espO,bb);
pcall(function ()
end
end)
S1:AddButton({
end)
equipSpecific(Options.EquipItem.Value);
local bases=WS:FindFirstChild("Bases");
local T1=Tabs.TP:AddLeftGroupbox("Bases");
posFirst=true;
tool.Parent=getChar();
task.spawn(function ()
for _,ore in ipairs(o:GetChildren()) do ;if ore:IsA("Model") then ;local p=getPart(ore);if p then ;table.insert(l,{Obj=ore,Name=ore.Name,Part=p,Pos=p.Position}); end ; end ; end ;
task.spawn(function ()
Default=5000,;
end)
M3:AddButton({Text="Hunt Boss",Func=bossHunt});
local function getHum()
M1:AddButton({
while Toggles and Toggles.OreFarm and Toggles.OreFarm.Value do ;local ores=getOres();local hrp=getHRP();if hrp then ;local f={};local t=(Options and Options.OreT and Options.OreT.Value) or "ALL";for _,o in ipairs(ores) do ;if t=="ALL" or o.Name==t then ;table.insert(f,o); end ; end ;table.sort(f,function (a,b);return (hrp.Position-a.Pos).Magnitude<(hrp.Position-b.Pos).Magnitude; end);local ore=f[1];if ore and ore.Obj and ore.Obj.Parent then ;local eq=getEquipped();if not eq or not eq.Name:lower():find("pick") then ;for _,x in ipairs(LP.Backpack:GetChildren()) do ;if x:IsA("Tool") and x.Name:lower():find("pick") then ;x.Parent=LP.Character;task.wait(0.2);break; end ; end ; end ;local mp=ore.Pos+Vector3.new(0,3,5);local s=tick();while Toggles.OreFarm.Value and ore.Obj and ore.Obj.Parent and tick()-s<8 do ;local h=getHRP();if h then ;h.CFrame=CFrame.lookAt(mp,ore.Pos);h.AssemblyLinearVelocity=Vector3.zero; end ;pcall(function ();VI:SendMouseButtonEvent(0,0,0,true,game,0);task.wait(0.05);VI:SendMouseButtonEvent(0,0,0,false,game,0); end);attackWithAllWeapons();task.wait(0.15); end ; else ;task.wait(0.5); end
end)
LP.CharacterAdded:Connect(function (c)
if not rf then ;return ; end ;
if not isfile or not isfile("BCWHub/themes/default.json") then ;ThemeManager:ApplyTheme("Quartz"); else ;SaveManager:LoadAutoloadConfig(); end ;
if not tool then ;return ; end ;
task.wait(0.3);
local torso=getTorso();
Rounding=0;
local tool=findToolByName("Trepid Terror");
lbl.BackgroundColor3=Color3.fromRGB(0,0,0);
local function startNC()
return true;
Options.OreT:SetValues(getOreTypes());
local count=0;
table.sort(bs,function (a,b)
end)
end)
E2:AddButton({
local M1=Tabs.Main:AddLeftGroupbox("Mob Farm");
for n,_ in pairs(SUMMON_MAP) do ;S2:AddButton({;Text=n,;Func=function ();local method=SUMMON_MAP[n];if type(method)=="table" then ;for _,m in ipairs(method) do ;summonCompanion(n,m);task.wait(0.05); end ; else ;summonCompanion(n,method); end ;notify(n,2); end
Default=500,;
Settings=Window:AddTab("UI");
notify("BCW Hub v19 loaded",3);
end
return m.MaxHp>5000;
})
return n;
Text="Find Portals",;
local function getOres()
for n,_ in pairs(SUMMON_MAP) do ;if findToolByName(n) then ;table.insert(l,n); end ; end ;
while true do ;local speed=(Options and Options.TrepidSpeed and Options.TrepidSpeed.Value) or 0.05;task.wait(speed);if not (Toggles and Toggles.TrepidSpam and Toggles.TrepidSpam.Value) then ;continue; end ;local hrp=getHRP();if not hrp then ;continue; end ;local radius=(Options and Options.TrepidRadius and Options.TrepidRadius.Value) or 500;local targets={};for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=radius and m.Hum.Health>0 then ;table.insert(targets,m); end ; end ;if #targets>0 then ;trepidShootAll(targets); end ; end ;
end)
end
task.spawn(function ()
Text="TP",;
end
C1:AddToggle("KillAuraAggressive",{Text="🚀 AGGRESSIVE"});
task.spawn(function ()
Func=function ()
SaveManager:BuildConfigSection(Tabs.Settings);
end
local fa={};
bb.Adornee=p;
end
Min=0.01,;
local m=WS:FindFirstChild("Map");
if tool.Parent~=c then ;tool.Parent=c;task.wait(0.05); end ;
lbl.Font=Enum.Font.GothamBold;
t.TextSize=13;
end
})
end
local repo="https://raw.githubusercontent.com/violin-suzutsuki/LinoriaLib/main/";
if not Library then ;warn("[BCW]LINORIA FAILED");return ; end ;
Lighting.FogEnd=1000000000;
end
for _,p in ipairs(Players:GetPlayers()) do ;if p~=LP then ;table.insert(n,p.Name); end ; end ;
D1:AddToggle("AutoAcceptTP",{Text="Auto YES",Default=true});
V1:AddToggle("PlrESP",{Text="Player"});
local n,s={"ALL"},{};
}
end
hl.Adornee=p.Parent;
Func=function ()
M2:AddToggle("AntiDeath",{Text="Anti-Death"});
Max=0.5,;
end
if not mfTarget or not mfTarget.Obj or not mfTarget.Obj.Parent or not mfTarget.Hum or mfTarget.Hum.Health<=0 then ;return ; end ;
Rounding=2;
M1:AddToggle("MobFarm",{Text="Enabled"}):OnChanged(function ()
T1:AddDropdown("BT",{Text="Base",Default="",Values={""}});
hl.OutlineColor=o.color;
}
pcall(function ()
hl.FillColor=o.color;
end
local function realInstakillMob(mob)
if tick()-lt>=1 then ;lbl.Text="FPS: " .. fr;fr=0;lt=tick(); end ;
task.spawn(function ()
T1:AddButton({
notify("Particles off",2);
end
end)
end)
end)
Default=0.1,;
task.spawn(function ()
local function allTools()
while true do ;task.wait(0.12);if Toggles and Toggles.AutoM1 and Toggles.AutoM1.Value then ;pcall(function ();VI:SendMouseButtonEvent(0,0,0,true,game,0);task.wait(0.02);VI:SendMouseButtonEvent(0,0,0,false,game,0); end); end
return n;
flyBV.MaxForce=Vector3.new(9000000000,9000000000,9000000000);
})
S1:AddToggle("CompESP",{Text="Companion ESP"});
local c=getChar();
T1:AddButton({
end)
local C1=Tabs.Combat:AddLeftGroupbox("⚔ Kill Aura");
return c and c:FindFirstChild("Torso");
notify("FPS boost",2);
Comps=Window:AddTab("Summon"),;
local C1B=Tabs.Combat:AddLeftGroupbox("🔫 Trepid Shoot");
if c then ;for _,o in ipairs(c:GetChildren()) do ;if o:IsA("Tool") then ;table.insert(t,o); end ; end ; end ;
else ;
local o=m:FindFirstChild("Ores");
local UIS=game:GetService("UserInputService");
D2:AddButton({
if cfg then ;if cfg.reset then ;pcall(function ();rf:InvokeServer(cfg.reset,{}); end); end
C2:AddToggle("AutoIKAggressive",{Text="🚀 AGGRESSIVE"});
task.wait(0.5);
hrp.AssemblyLinearVelocity=Vector3.zero;
M1:AddDivider();
Rounding=0;
Func=function ()
})
ThemeManager=nil;
while true do ;task.wait(0.03);if not (Toggles and Toggles.KillAura and Toggles.KillAura.Value and Toggles.KillAuraAggressive and Toggles.KillAuraAggressive.Value) then ;continue; end ;local hrp=getHRP();if not hrp then ;continue; end ;local r=(Options and Options.KAR and Options.KAR.Value) or 100;for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=r and m.Hum.Health>0 then ;local tool=getEquipped();if tool then ;task.spawn(function ();realWeaponAttack(tool,m); end); end ; end ; end
local hrp=getHRP();
if Toggles.OreFarm.Value then ;oreLoop(); end ;
end
local DUNGEONS={
end
rf:InvokeServer(method,{hrp.Position,torso});
local SUMMON_MAP={
end
local Tabs={
end
Rounding=0;
local fr,lt=0,tick();
if arm then ;arm.Value=0; end ;
}
Default=60,;
t.TextStrokeTransparency=0;
{"Eye of Storm","EyeOfTheStorm"},;
end
local E1=Tabs.Equip:AddLeftGroupbox("Equip");
return l;
task.spawn(function ()
rf:InvokeServer("lightpunch");
end
task.spawn(function ()
end)
notify("Not found: " .. sub,3);
hl.FillTransparency=0.6;
end
if o:IsA("BasePart") then ;return o; end ;
task.spawn(function ()
local c=getChar();
t.Size=UDim2.new(1,0,1,0);
flyBV.Velocity=Vector3.zero;
local LP=Players.LocalPlayer;
local function getChar()
end)
{"Khrysos","KhrysosTemple"},;
hl.DepthMode=Enum.HighlightDepthMode.AlwaysOnTop;
local h=getHRP();
for i=1,30 do ;if not mob.Obj.Parent or mob.Hum.Health<=0 then ;break; end ;attackWithAllWeapons(mob);task.wait(0.1); end ;
if UIS:IsKeyDown(Enum.KeyCode.LeftShift) then ;d=d-Vector3.new(0,1,0); end ;
MV1:AddToggle("FpsCounter",{Text="FPS Counter"});
if not hrp then ;return ; end ;
V1:AddToggle("UnlimitedRange",{Text="UNLIMITED"});
end)
local t=Instance.new("TextLabel",bb);
MV1:AddSlider("WS",{
local n,s={"ALL"},{};
for _,o in ipairs(getOres()) do ;if not s[o.Name] then ;s[o.Name]=true;table.insert(n,o.Name); end ; end ;
local function tpDungeon(sub)
stopFly();
local hrp=getHRP();
end)
Size=UDim2.fromOffset(500,500);
TabPadding=4,;
MenuFadeTime=0.2,;
pcall(function ()
local flyBV,flyBG,flyC;
})
rf:InvokeServer("destroyitself",{});
end
})
local c=getChar();
M3:AddButton({Text="Ability Spam",Func=abilitySpam});
Text="Speed",;
task.spawn(function ()
if ijC then ;return ; end ;
for _,t in ipairs(allTools()) do ;if t.Name==name then ;return t; end ; end ;
needsPos=true,;
pcall(function ()
local function mkESP(p,o)
F1:AddButton({
V1:AddToggle("MobESP",{Text="Mob/Boss"});
local rf=tool:FindFirstChildOfClass("RemoteFunction");
local t={};
end)
local hrp=getHRP();
MV2:AddToggle("FlyEnabled",{Text="Fly"}):OnChanged(function ()
fr=fr+1;
if not c then ;return ; end ;
D2:AddButton({Text="TP to Portal",Func=tpToMinePortal});
Default=50,;
if Toggles and Toggles.NoClip and Toggles.NoClip.Value then ;local c=getChar();if c then ;for _,p in ipairs(c:GetDescendants()) do ;if p:IsA("BasePart") then ;p.CanCollide=false; end ; end ; end ; end ;
end
})
Options.OreT:SetValues(getOreTypes());
C3:AddButton({Text="Kill All",Func=killAllInMap});
Min=50,;
local rf=charTool:FindFirstChildOfClass("RemoteFunction");
if not fps.Parent then ;fps.Parent=LP.PlayerGui; end ;
end)
Min=100,;
end)
local D2=Tabs.Dgn:AddRightGroupbox("Portal");
bb.AlwaysOnTop=true;
if cfg.needsPos and mob and mob.Pos then ;if cfg.posFirst then ;table.insert(fa,mob.Pos);for _,a in ipairs(cfg.args) do ;table.insert(fa,a); end ; else ;for _,a in ipairs(cfg.args) do ;table.insert(fa,a); end ;table.insert(fa,mob.Pos); end ; else ;for _,a in ipairs(cfg.args) do ;table.insert(fa,a); end ; end ;
pcall(function ()
local function findToolByName(name)
task.wait(0.3);
end
{"Blue Sea","BlueSea"},;
local Window=Library:CreateWindow({
["Fang of Gilgamesh"]=function (rf)
["Trepid Terror"]={"createarm","creature"},;
Options.MobT:SetValue("ALL");
end)
local c=getChar();
if Toggles.InfJump.Value then ;startIJ(); else ;stopIJ(); end ;
end
rf:InvokeServer("realitytear");
if not hrp then ;return ; end ;
})
local data=HTTP:JSONDecode(body);
if data and data.data then ;for _,s in ipairs(data.data) do ;if (s.playing or 0)<(s.maxPlayers or 0) and s.id~=game.JobId then ;table.insert(good,s); end ; end ; end ;
table.sort(n,function (a,b)
C2:AddToggle("AutoInstakill",{Text="AUTO INSTAKILL"});
end)
if m then ;local hrp=getHRP();if hrp then ;pcall(function ();rf:InvokeServer("shoot",{hrp.Position,m.Pos}); end); end
return killed;
local cfg=WEAPON_ATTACK[tool.Name];
end
t.TextColor3=o.color or Color3.new(1,1,1);
pcall(function ()
local b=WS:FindFirstChild("Bases");
end
local S2=Tabs.Comps:AddRightGroupbox("Individual");
if #n>0 then ;Options.PT:SetValues(n);Options.PT:SetValue(n[1]); end ;
{"Caverns","Caverns"},;
if not rf then ;return ; end ;
Text="Refresh",;
Func=function ()
for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=(radius or 1000) and m.Hum.Health>0 then ;realInstakillMob(m);killed=killed+1; end ; end ;
if not tool then ;return false; end ;
table.sort(n);
notify("Killing " ..#mobs,3);
Text="Radius",;
Library:Notify(t,d or 3);
end
Max=500,;
local part=mfTarget.Part;
Func=function ()
["Ban Hammer"]=function (rf)
M3:AddButton({Text="FPS Boost",Func=fpsBoost});
})
Rounding=0;
E1:AddButton({Text="Equip ALL",Func=equipAll});
{"The Void","TheVoid"};
nc=RunService.Stepped:Connect(function ()
Text="Refresh",;
end
return c;
if #l==0 then ;notify("None",3);return ; end ;
end
rf:InvokeServer("hit",{8000,2});
rf:InvokeServer("creature");
end)
mfTarget=nil;
bringAllMobs(1000);
C3:AddToggle("AutoM1",{Text="Auto M1"});
Toggles=nil;
if b then ;for _,x in ipairs(b:GetChildren()) do ;local o=x:FindFirstChild("owner");local n=x.Name .. "(" ..((o and o.Value and o.Value.Name) or "None").. ")";if n==s then ;local sp=x:FindFirstChild("spawn");if sp then ;tpA(sp.Position,5); end ;break; end ; end ; end ;
ESP=Window:AddTab("ESP"),;
Move=Window:AddTab("Move"),;
for _,m in ipairs(getMobs(false)) do ;if not s[m.Name] then ;s[m.Name]=true;table.insert(n,m.Name); end ; end ;
t.BackgroundTransparency=1;
lbl.Visible=Toggles and Toggles.FpsCounter and Toggles.FpsCounter.Value or false;
T2:AddButton({
local WEAPON_EXTRAS={
["Equinox Seal"]="Twilight",;
["Eldritch Tentacles"]="Abomination",;
pcall(function ()
end
pcall(function ()
end)
["Ban Hammer"]={method="hit",args={1},needsPos=true},;
["Extinction Ray"]={method="shoot",args={},needsPos=true},;
local bases=WS:FindFirstChild("Bases");
C1B:AddSlider("TrepidSpeed",{
AutoShow=true,;
local function bringAllMobs(radius)
Library.ToggleKeybind=Options.MenuKeybind;
ThemeManager:SetLibrary(Library);
Func=function ()
hrp.AssemblyAngularVelocity=Vector3.zero;
if bases then ;for _,base in ipairs(bases:GetChildren()) do ;local objs=base:FindFirstChild("objects");if objs then ;for _,obj in ipairs(objs:GetChildren()) do ;if obj:GetAttribute("SubplaceName")==sub then ;local part=obj:FindFirstChild("center") or obj:FindFirstChild("pad") or getPart(obj);if part then ;local hrp=getHRP();if hrp then ;hrp.CFrame=CFrame.new(part.Position+Vector3.new(0,3,0));hrp.AssemblyLinearVelocity=Vector3.zero; end ;notify("TP " .. sub,2);return ; end ; end ; end ; end ; end ; end ;
SaveManager=nil;
E2:AddDropdown("EquipItem",{Text="Item",Default="",Values={""}});
end
elseif d:IsA("Decal") or d:IsA("Texture") then ;
local tool=findToolByName(toolName);
end)
if not o then ;return l; end ;
RunService.RenderStepped:Connect(function ()
Library=nil;
C1:AddSlider("KASpeed",{
local function getEquipped()
task.wait(0.2);
if orig and orig.Parent==LP.Backpack then ;orig.Parent=getChar(); end ;
T2:AddDropdown("PT",{Text="Player",Default="",Values={""}});
end)
while true do ;task.wait(1);if Toggles and Toggles.NoFog and Toggles.NoFog.Value then ;Lighting.FogEnd=100000;Lighting.FogStart=100000;for _,at in ipairs(Lighting:GetChildren()) do ;if at:IsA("Atmosphere") then ;pcall(function ();at.Density=0;at.Haze=0; end); end ; end ; end
Max=0.5,;
end
M1:AddToggle("BossOnly",{Text="Boss Only"});
E1:AddToggle("CycleEquip",{Text="Cycle Loop"});
if not tool then ;return ; end ;
return (hrp.Position-a.Pos).Magnitude<(hrp.Position-b.Pos).Magnitude;
flyC=RunService.RenderStepped:Connect(function ()
task.spawn(function ()
["Staff of Conflict"]={method="ConflictOrbs",args={},needsPos=true},;
["Suspicious Invitation"]="summon";
local function trepidShootAll(mobs)
while true do ;task.wait(1);if Toggles and Toggles.AntiDeath and Toggles.AntiDeath.Value then ;local h=getHRP();if h then ;savedPos=h.CFrame; end ; end ; end ;
SaveManager:IgnoreThemeSettings();
task.spawn(function ()
Max=500,;
local function rmParticles()
task.spawn(function ()
Options.MobT:SetValues(getMobNames());
end)
local nc;
local orig=getEquipped();
end
for name,method in pairs(SUMMON_MAP) do ;if findToolByName(name) then ;count=count+1;task.spawn(function ();if type(method)=="table" then ;for _,m in ipairs(method) do ;summonCompanion(name,m); end ; else ;summonCompanion(name,method); end ; end); end
end
while true do ;task.wait(0.2);if Toggles and Toggles.AutoAcceptTP and Toggles.AutoAcceptTP.Value then ;local tg=LP.PlayerGui:FindFirstChild("TeleportGui");if tg then ;for _,f in ipairs({tg:FindFirstChild("Frame"),tg:FindFirstChild("FrameReal")}) do ;if f and f.Visible then ;local rem=f:FindFirstChild("Remote");if rem and rem.Value then ;pcall(function ();rem.Value:InvokeServer(); end); end ; end ; end ; end ; end
SaveManager:SetFolder("BCWHub");
Max=1000,;
local function attackWithAllWeapons(mob)
if not part or not part.Parent then ;return ; end ;
end
while true do ;task.wait(0.3);if Toggles and Toggles.CycleEquip and Toggles.CycleEquip.Value then ;local tools=allTools();if #tools>0 then ;idx=(idx%#tools)+1;local t=tools[idx];if t and t.Parent==LP.Backpack then ;pcall(function ();t.Parent=getChar(); end); end ; end ; end
end
pcall(function ()
C1B:AddToggle("TrepidSpam",{Text="🔫 TREPID SHOOT"});
end
task.spawn(function ()
end)
lbl.TextSize=14;
end)
local function isBoss(m)
if g then ;return ; end ;
local function getHRP()
local charTool=c:FindFirstChild(toolName);
end)
["Apocalypse"]={method="hit",args={150,2}},;
local function summonCompanion(toolName,method)
end
local RunService=game:GetService("RunService");
return n;
pcall(function ()
end)
local function bossHunt()
local WS=game:GetService("Workspace");
local function tpA(pos,y)
if not hrp then ;return ; end ;
end)
})
Max=5000,;
local bs={};
Min=50,;
if flyBG then ;flyBG:Destroy();flyBG=nil; end ;
for _,m in ipairs(getMobs(false)) do ;if isBoss(m) then ;table.insert(bs,m); end ; end ;
S1:AddToggle("AutoSummon",{Text="Auto Loop(5s)"});
for _,t in ipairs(allTools()) do ;table.insert(n,t.Name); end ;
}
method="hit",;
Min=50,;
end
["Yin Yang"]=function (rf)
notify("Killing " .. instakillAllInRadius(500),2);
end)
end)
Text="Equip",;
})
M3:AddButton({Text="Rm Particles",Func=rmParticles});
C3:AddToggle("AutoAtk",{Text="Auto Attack"});
end
local count=0;
V2:AddToggle("FullBright",{Text="Full Bright"});
TP=Window:AddTab("TP"),;
end
Rounding=0;
end
ThemeManager:SetFolder("BCWHub");
hrp.CFrame=CFrame.new(c[1].Pos+Vector3.new(0,3,0));
d.Transparency=1;
local hrp=getHRP();
end)
fps.Parent=game:GetService("CoreGui");
end
C3:AddButton({Text="Ability Spam",Func=abilitySpam});
if h then ;h.CFrame=CFrame.new(pos+Vector3.new(0,y or 4,0));h.AssemblyLinearVelocity=Vector3.zero; end ;
fps.Name="BCWFps";
local Lighting=game:GetService("Lighting");
local E2=Tabs.Equip:AddRightGroupbox("Select");
else ;
local rf=tool:FindFirstChildOfClass("RemoteFunction");
Options.EquipItem:SetValues(getAllToolNames());
M3:AddButton({
method="Swing",;
C2:AddSlider("AutoIKRadius",{
LP.Idled:Connect(function ()
local s=Options.BT.Value;
if mob and mob.Pos then ;pcall(function ();rf:InvokeServer("hit",{8000,mob.Pos}); end)
for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=(radius or 500) then ;pcall(function ();m.Part.CFrame=hrp.CFrame*CFrame.new(0,0,-5);m.Part.AssemblyLinearVelocity=Vector3.zero; end);count=count+1; end
end
end)
if o:IsA("Model") then ;return o.PrimaryPart or o:FindFirstChild("HumanoidRootPart") or o:FindFirstChild("Torso") or o:FindFirstChildWhichIsA("BasePart"); end ;
Default=0.05,;
for _,d in ipairs(WS:GetDescendants()) do ;if d:IsA("ParticleEmitter") or d:IsA("Trail") or d:IsA("Beam") then ;pcall(function ();d.Enabled=false; end);elseif d:IsA("MeshPart") or d:IsA("Part") then ;pcall(function ();d.Material=Enum.Material.Plastic; end)
end
local function tpToMinePortal()
end)
pcall(function ()
Func=function ()
end
end
for _,tool in ipairs(LP.Backpack:GetChildren()) do ;if tool:IsA("Tool") then ;tool.Parent=c;count=count+1;task.wait(0.05); end ; end ;
E2:AddButton({
MV1:AddToggle("NoClip",{Text="NoClip"}):OnChanged(function ()
end
if not mob or not mob.Obj or not mob.Hum or mob.Hum.Health<=0 then ;return ; end ;
if not (Toggles and Toggles.MobFarm and Toggles.MobFarm.Value and Toggles.MFTP and Toggles.MFTP.Value) then ;return ; end ;
["Mysterious Artifact"]="summon",;
M1:AddDropdown("MobT",{Text="Target",Default="ALL",Values={"ALL"}});
local c=getChar();
end)
local C2=Tabs.Combat:AddRightGroupbox("Auto Instakill");
notify(table.concat(n,"\n"),5);
if Toggles and Toggles.AutoRejoin and Toggles.AutoRejoin.Value then ;task.wait(3);pcall(function ();TS:TeleportToPlaceInstance(game.PlaceId,game.JobId,LP); end)
realInstakillMob(bs[1]);
Text="Speed",;
local c={};
Func=function ()
MV1:AddToggle("InfJump",{Text="Inf Jump"}):OnChanged(function ()
C1:AddLabel("Экипированное оружие");
end
if not m then ;return l; end ;
if count>0 then ;notify("Summoned " .. count,2); end ;
local bb=Instance.new("BillboardGui");
Max=10000,;
})
for _,tool in ipairs(allTools()) do ;pcall(function ();realWeaponAttack(tool,mob); end)
Dgn=Window:AddTab("Dgn"),;
Min=0.05,;
return true;
return t;
local function getTorso()
["Equinox Slicer"]={
pcall(function ()
["Spirit Glaive"]={method="hit",args={},reset="weld"},;
lbl.BackgroundTransparency=0.4;
lbl.TextColor3=Color3.fromRGB(0,255,0);
end)
Options.OreT:SetValue("ALL");
end)
C1B:AddSlider("TrepidRadius",{
Text="Fly Speed",;
end
Rounding=2;
if #good==0 then ;notify("None",2);return ; end ;
if Toggles and Toggles.InfJump and Toggles.InfJump.Value then ;local h=getHum();if h then ;h:ChangeState(Enum.HumanoidStateType.Jumping); end ; end ;
pcall(function ()
end
local function startFly()
while true do ;task.wait(0.03);if Toggles and Toggles.AutoInstakill and Toggles.AutoInstakill.Value and Toggles.AutoIKAggressive and Toggles.AutoIKAggressive.Value then ;local hrp=getHRP();if hrp then ;local radius=(Options and Options.AutoIKRadius and Options.AutoIKRadius.Value) or 500;for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=radius and m.Hum.Health>0 then ;task.spawn(function ();attackWithAllWeapons(m); end); end ; end ; end ; end
})
local n={};
end)
end
MV1:AddSlider("JP",{
end
if UIS:IsKeyDown(Enum.KeyCode.A) then ;d=d-cam.CFrame.RightVector; end ;
M1:AddToggle("BringMobsLoop",{Text="Bring Mobs"});
M1:AddButton({
Text="Bring All",;
end)
return c and c:FindFirstChild("HumanoidRootPart");
end
for _,g in ipairs(game:GetService("CoreGui"):GetChildren()) do ;if g.Name=="BCWHub" or g.Name:find("Linoria") or g.Name=="BCWFps" then ;g:Destroy(); end ; end ;
Max=500,;
if i.KeyCode==Enum.KeyCode.T and Toggles and Toggles.Freeze then ;Toggles.Freeze:SetValue(true); end ;
flyBG.P=90000;
M2:AddToggle("AutoRejoin",{Text="Auto Rejoin",Default=true});
if Toggles and Toggles.JumpOn and Toggles.JumpOn.Value then ;local h=getHum();if h then ;pcall(function ();h.UseJumpPower=true;h.JumpPower=(Options and Options.JP and Options.JP.Value) or 50; end); end
local count=0;
if not h or not cam or not flyBV then ;return ; end ;
if bases then ;for _,base in ipairs(bases:GetChildren()) do ;local objs=base:FindFirstChild("objects");if objs then ;for _,obj in ipairs(objs:GetChildren()) do ;local n=obj.Name:lower();if n:find("dungeonteleporter") or n:find("mysteryteleporter") or n:find("beneath") or n:find("void") then ;local part=obj:FindFirstChild("center") or obj:FindFirstChild("pad") or getPart(obj);if part then ;table.insert(c,{Name=obj.Name,Pos=part.Position,Base=base.Name}); end ; end ; end ; end ; end ; end ;
["Unknown Signal Emitter"]="hologramactivate",;
lbl.Size=UDim2.new(0,100,0,25);
end)
["Ominous Dark Egg"]="Fiscus",;
["Magic Conch"]="Siren",;
local function startIJ()
end
local function getPart(o)
if UIS:IsKeyDown(Enum.KeyCode.S) then ;d=d-cam.CFrame.LookVector; end ;
end
if not rf then ;return false; end ;
local body=game:HttpGet("https://games.roblox.com/v1/games/" .. game.PlaceId .. "/servers/Public?sortOrder=Asc&limit=100");
task.spawn(function ()
local c=getChar();
after="motor6dremove";
}
reset="motor6dconnect",;
end
task.spawn(function ()
Equip=Window:AddTab("Equip"),;
UIS.InputBegan:Connect(function (i,g)
table.insert(espO,hl);
local function instantSummonAll()
Func=function ()
local tool=getEquipped();
end)
local tool=findToolByName(name);
if not tool then ;notify("Not found",2);return ; end ;
},
local savedPos=nil;
end)
local function realWeaponAttack(tool,mob)
local fps=Instance.new("ScreenGui");
if nc then ;return ; end ;
end
end
Center=true,;
MV1:AddToggle("JumpOn",{Text="Jump"});
if flyBV then ;flyBV:Destroy();flyBV=nil; end ;
local SaveManager=loadstring(game:HttpGet(repo .. "addons/SaveManager.lua"))();
hl.Parent=p;
{"Creus Arena","CreusArena"},;
end
Min=10,;
local function instakillAllInRadius(radius)
if not hrp then ;return ; end ;
for _,e in ipairs(espO) do ;pcall(function ();e:Destroy(); end)
{"Omens of War","OmensOfWar"},;
end)
if #bs==0 then ;notify("No bosses",2);return ; end ;
["The Light Illuminating the World"]={
Text="Instakill 500m",;
C1B:AddLabel("shoot()по ВСЕМ мобам");
while true do ;task.wait(0.1);if Toggles and Toggles.NoCD and Toggles.NoCD.Value then ;local c=getChar();if c then ;local cd=c:FindFirstChild("Cooldowns");if cd then ;for _,x in ipairs(cd:GetChildren()) do ;pcall(function ();x:Destroy(); end); end ; end ; end ; end
end
V2:AddToggle("NoFog",{Text="No Fog"});
notify("Equipped " .. count,2);
pcall(function ()
end
})
for _,ab in ipairs({;"consumerspikes",;"consumertrains",;"realitytear",;"destroyitself",;"slam",;"slambarrage",;"Swing",;"dash",;"Rush",;"lightpunch",;"creature";}) do ;pcall(function ();rf:InvokeServer(ab); end)
if not hrp then ;return 0; end ;
local d=Vector3.zero;
if ijC then ;ijC:Disconnect();ijC=nil; end ;
if a=="ALL" then ;return true;elseif b=="ALL" then ;return false; end ;
task.spawn(function ()
local Players=game:GetService("Players");
local function abilitySpam()
{"Aurora Glacier","AuroraGlacier"},;
})
end)
local MV2=Tabs.Move:AddRightGroupbox("Fly");
notify("Portal: " .. c[1].Name,2);
task.spawn(function ()
C1B:AddToggle("TrepidAggressive",{Text="🚀 AGGRESSIVE"});
Func=function ()
end
})
end ,
local l={};
hrp.AssemblyLinearVelocity=Vector3.zero;
local function clearESP()
end)
lbl.Position=UDim2.new(0,10,0,40);
Rounding=0;
T2:AddButton({
TS:TeleportToPlaceInstance(game.PlaceId,good[math.random(1,#good)].id,LP);
Text="Speed",;
end
})
local VI=game:GetService("VirtualInputManager");
end
["Trepid Terror"]=function (rf,m)
end)
pcall(function ()
M1:AddToggle("MFTP",{Text="Hover Above"});
while true do ;task.wait(0.15);if Toggles and Toggles.AutoAtk and Toggles.AutoAtk.Value then ;local hrp=getHRP();if hrp then ;local n,dd=nil,math.huge;for _,m in ipairs(getMobs(false)) do ;local d=(hrp.Position-m.Pos).Magnitude;if d<dd and m.Hum.Health>0 then ;dd=d;n=m; end ; end ;if n and dd<500 then ;local tool=getEquipped();if tool then ;realWeaponAttack(tool,n); end ; end ; end ; end ; end ;
MV1:AddToggle("SpeedOn",{Text="Speed"});
for _,o in ipairs(LP.Backpack:GetChildren()) do ;if o:IsA("Tool") then ;table.insert(t,o); end ; end ;
M3:AddButton({Text="KILL ALL",Func=killAllInMap});
espO={};
flyBG=Instance.new("BodyGyro",hrp);
["Spirit Glaive"]=function (rf,m)
pcall(function ()
local n={};
rf:InvokeServer("consumerspikes");
pcall(function ()
Combat=Window:AddTab("Combat"),;
Func=function ()
local function stopNC()
})
bb.StudsOffset=Vector3.new(0,3,0);
local function getAllToolNames()
C1:AddToggle("KillAura",{Text="⚔ KILL AURA"});
while true do ;task.wait(0.1);if Toggles and Toggles.BringMobsLoop and Toggles.BringMobsLoop.Value then ;local hrp=getHRP();if hrp then ;for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=300 and m.Hum.Health>0 then ;pcall(function ();m.Part.CFrame=hrp.CFrame*CFrame.new(0,0,-4);m.Part.AssemblyLinearVelocity=Vector3.zero; end); end ; end ; end ; end
if nc then ;nc:Disconnect();nc=nil; end ;
local function mobFarmLoop()
V1:AddSlider("ESPD",{
local WEAPON_ATTACK={
["Trepid Terror"]={method="hit",args={1000,2.5,4}},;
end ,
if m and m.Part then ;pcall(function ();rf:InvokeServer("dash",{m.Part.CFrame}); end)
end
end)
Max=1,;
local n=getAllToolNames();
while true do ;task.wait(0.1);if Toggles and Toggles.SpeedOn and Toggles.SpeedOn.Value then ;local h=getHum();if h then ;pcall(function ();h.WalkSpeed=(Options and Options.WS and Options.WS.Value) or 24; end); end ; end
while true do ;task.wait(5);if Toggles and Toggles.AutoSummon and Toggles.AutoSummon.Value then ;instantSummonAll(); end ; end ;
rf:InvokeServer("slam");
end)
Default=24,;
Min=16,;
end)
["Fang of Gilgamesh"]={method="hit",args={8000,2},reset="destroyitself"},;
["Yin Yang"]={method="hit",args={2},needsPos=true},;
D1:AddDivider();
})
if Toggles and Toggles.AutoSummon and Toggles.AutoSummon.Value then ;task.wait(3);instantSummonAll(); end ;
flyBG.MaxTorque=Vector3.new(9000000000,9000000000,9000000000);
local function freeze(s)
M2:AddToggle("AntiFall",{Text="Anti-Fall"});
pcall(function ()
return true;
notify("→ " .. bs[1].Name,3);
local function oreLoop()
rf:InvokeServer("consumertrains");
end)
end
end
local idx=1;
if not c then ;return false; end ;
notify("Brought " .. count,2);
end
local function stopIJ()
local ijC;
end ,
while true do ;task.wait(0.03);if not (Toggles and Toggles.TrepidSpam and Toggles.TrepidSpam.Value and Toggles.TrepidAggressive and Toggles.TrepidAggressive.Value) then ;continue; end ;local hrp=getHRP();if not hrp then ;continue; end ;local radius=(Options and Options.TrepidRadius and Options.TrepidRadius.Value) or 500;local targets={};for _,m in ipairs(getMobs(false)) do ;if (hrp.Position-m.Pos).Magnitude<=radius and m.Hum.Health>0 then ;table.insert(targets,m); end ; end ;if #targets>0 then ;trepidShootAll(targets); end ; end ;
pcall(function ()
end)
flyBV.Velocity=d*((Options and Options.FS and Options.FS.Value) or 60);
flyBG.CFrame=cam.CFrame;
Text="Radius",;
pcall(function ()
if tool.Name=="Trepid Terror" and mob then ;local hrp=getHRP();if hrp then ;pcall(function ();rf:InvokeServer("createarm",{true,hrp.CFrame}); end); end
return a.MaxHp>b.MaxHp;
local T2=Tabs.TP:AddRightGroupbox("Players");
local rf=tool:FindFirstChildOfClass("RemoteFunction");
if b then ;for _,x in ipairs(b:GetChildren()) do ;local o=x:FindFirstChild("owner");table.insert(n,x.Name .. "(" ..((o and o.Value and o.Value.Name) or "None").. ")"); end ; end ;
})
end)
local function fpsBoost()
end)
SaveManager:SetLibrary(Library);
end ,
local function findPlayerPortal()
function getMobs(incComp);local l,pn={},{};for _,p in ipairs(Players:GetPlayers()) do ;pn[p.Name]=true; end ;for _,o in ipairs(WS:GetChildren()) do ;if o:IsA("Model") and not pn[o.Name] then ;local h=o:FindFirstChildOfClass("Humanoid");local r=o:FindFirstChild("HumanoidRootPart") or o:FindFirstChild("Torso");if h and r and h.Health>0 then ;local ic=o:FindFirstChild("AlliedSummon") or o:FindFirstChild("OwnerTag");if incComp or not ic then ;table.insert(l,{;Obj=o,;Name=o.Name,;Hum=h,;Part=r,;Pos=r.Position,;MaxHp=h.MaxHealth,;IsComp=ic~=nil;}); end ; end ; end ; end ;return l; end ;

-- ======== ФРАГМЕНТЫ С НЕОДНОЗНАЧНЫМ ПОРЯДКОМ (72 шт.) ========
-- Диспетчер обфускатора повреждён (коллизии bxor-кодера границ), поэтому точное
-- место этих фрагментов в цепочке статически не восстановимо. Фрагменты сцеплены
-- по их собственным next-переходам.
RunService.Heartbeat:Connect(function ()
local h=getHRP();
local TS=game:GetService("TeleportService");
end
for _,p in ipairs(c) do ;table.insert(n,p.Name .. " @ " .. p.Base); end ;
})
end
Default=500,;
Lighting.GlobalShadows=false;
game:GetService("GuiService").ErrorMessageChanged:Connect(function ()
end)
flyBV=Instance.new("BodyVelocity",hrp);
local hl=Instance.new("Highlight");
local V1=Tabs.ESP:AddLeftGroupbox("ESP");
end
for _,d in ipairs(DUNGEONS) do ;D1:AddButton({Text=d[1],Func=function ();tpDungeon(d[2]); end })
for _,o in ipairs(c:GetChildren()) do ;if o:IsA("Tool") then ;return o; end ; end ;
if i.KeyCode==Enum.KeyCode.Y and Toggles and Toggles.Freeze then ;Toggles.Freeze:SetValue(false); end ;
rf:InvokeServer("dualwield",false);
end
while Toggles and Toggles.MobFarm and Toggles.MobFarm.Value do ;local mobs=getMobs(false);local f={};local t=(Options and Options.MobT and Options.MobT.Value) or "ALL";local bo=Toggles and Toggles.BossOnly and Toggles.BossOnly.Value;for _,m in ipairs(mobs) do ;if not (bo and not isBoss(m)) then ;if t=="ALL" or m.Name==t then ;table.insert(f,m); end ; end ; end ;local hrp=getHRP();if hrp then ;table.sort(f,function (a,b);return (hrp.Position-a.Pos).Magnitude<(hrp.Position-b.Pos).Magnitude; end); end
args={2},;
local mobs=getMobs(false);
local p=Players:FindFirstChild(Options.PT.Value);
Rounding=0;
local function equipSpecific(name)
pcall(function ()
end)
bb.Parent=p;
local n={};
end
pcall(function ()
end)
if flyC then ;flyC:Disconnect();flyC=nil; end ;
hrp.CFrame=CFrame.lookAt(part.Position+Vector3.new(0,12,0),part.Position);
end
local c=findPlayerPortal();
while true do ;task.wait(0.3);if Toggles and Toggles.AntiFall and Toggles.AntiFall.Value then ;local hrp=getHRP();local h=getHum();if hrp and h and h:GetState()==Enum.HumanoidStateType.Freefall then ;local r=WS:Raycast(hrp.Position,Vector3.new(0,-500,0));if r then ;hrp.CFrame=CFrame.new(r.Position+Vector3.new(0,5,0));hrp.AssemblyLinearVelocity=Vector3.zero; end ; end ; end ; end ;
local espO={};
V2:AddToggle("MaxZoom",{Text="Max Zoom"});
Min=0.01,;
if cfg.after then ;pcall(function ();rf:InvokeServer(cfg.after,{}); end)
end
end)
if Options.MenuKeybind then ;Options.MenuKeybind:SetValue("RightControl"); end ;
local M2=Tabs.Main:AddLeftGroupbox("Protection");
task.spawn(function ()
S1:AddButton({Text="INSTANT Summon ALL",Func=instantSummonAll});
M2:AddToggle("AntiAFK",{Text="Anti-AFK",Default=true});
V1:AddToggle("OreESP",{Text="Ore"});
local S1=Tabs.Comps:AddLeftGroupbox("Summon");
if Toggles.MobFarm.Value then ;mobFarmLoop(); end ;
local HTTP=game:GetService("HttpService");
end)
local function srvHop()
rf:InvokeServer("slambarrage");
end
t.Text=o.text;
Farm=Window:AddTab("Farm"),;
MV2:AddLabel("WASD+Space/Shift");
})
return c and c:FindFirstChildOfClass("Humanoid");
if Toggles and Toggles.FullBright and Toggles.FullBright.Value then ;Lighting.Brightness=3;Lighting.ClockTime=14;Lighting.OutdoorAmbient=Color3.new(1,1,1);Lighting.Ambient=Color3.new(1,1,1);Lighting.GlobalShadows=false; end ;
C3:AddLabel("T/Y=Freeze");
F1:AddDropdown("OreT",{Text="Type",Default="ALL",Values={"ALL"}});
if UIS:IsKeyDown(Enum.KeyCode.D) then ;d=d+cam.CFrame.RightVector; end ;
Max=5000,;
end
end)
end)
task.wait(0.15);
end