// NZL Studio Obfuscator — static deobfuscator
// Walks the flattened state machine (while true do if a<=N ...) and
// reassembles fragments in execution order. No runtime execution needed.
import fs from 'fs';
import { tokenize } from './toklib.mjs';

const SRC_FILE = process.argv[2] ?? 'nzl_obf.lua';
const OUT_FILE = process.argv[3] ?? 'deobfuscated_raw.lua';
const src = fs.readFileSync(SRC_FILE, 'utf8');

// ---------------- tokenizer ----------------
const toks = tokenize(src);
const N = toks.length;
const isKw = (i, v) => i < N && toks[i].t === 'kw' && toks[i].v === v;
const isOp = (i, v) => i < N && toks[i].t === 'op' && toks[i].v === v;
const isName = (i, v) => i < N && toks[i].t === 'name' && toks[i].v === v;

// ---------------- constant expression eval ----------------
function numVal(tok) { const v = tok.v; if (/^0[bB]/.test(v)) return parseInt(v.slice(2).replace(/_/g,''), 2); if (/^0[xX]/.test(v)) return parseInt(v.slice(2).replace(/_/g,''), 16); return parseFloat(v.replace(/_/g,'')); }
function parseNumExpr(i) { // returns [value, nextIndex]
  let v, j;
  if (isName(i,'bit32') && isOp(i+1,'.') && isName(i+2,'bxor') && isOp(i+3,'(')) {
    const [a, k] = parseNumExpr(i+4);
    if (!isOp(k,',')) throw new Error('bxor comma expected @'+toks[k].s);
    const [b, k2] = parseNumExpr(k+1);
    if (!isOp(k2,')')) throw new Error('bxor close expected @'+toks[k2].s);
    v = ((a>>>0) ^ (b>>>0)) >>> 0; j = k2+1;
  } else if (isOp(i,'(')) {
    const [a, k] = parseNumExpr(i+1);
    if (!isOp(k,')')) throw new Error('paren close expected');
    v = a; j = k+1;
  } else if (toks[i]?.t === 'num') {
    v = numVal(toks[i]); j = i+1;
  } else throw new Error('bad const expr @'+(toks[i]?.s??i)+' '+JSON.stringify(toks.slice(i,i+4).map(t=>t.v)));
  while (isOp(j,'+')) { const [b, k] = parseNumExpr(j+1); v = v + b; j = k; }
  return [v, j];
}

// ---------------- locate dispatcher ----------------
let p = 0;
// find `local a = bit32.bxor(252,20161)` — unique init
let initIdx = -1;
for (let i = 0; i < N - 10; i++) {
  if (isName(i,'bit32') && isOp(i+1,'.') && isName(i+2,'bxor') && isOp(i+3,'(') && toks[i+4].t==='num' && numVal(toks[i+4])===252 && isOp(i+5,',') && toks[i+6].t==='num' && numVal(toks[i+6])===20161) { initIdx = i; break; }
}
if (initIdx < 0) throw new Error('initial state bit32.bxor(252,20161) not found');
const [a0, afterInit] = parseNumExpr(initIdx);
p = afterInit;
while (isOp(p,';')) p++;
if (!(isKw(p,'while') && isKw(p+1,'true') && isKw(p+2,'do'))) throw new Error('dispatcher while true do not found @'+toks[p].s);
p += 3;
while (isOp(p,';')) p++;

// ---------------- tree parser ----------------
const leaves = [];      // {lo, hi, fragStart, fragEnd, next, bound}
let stubCount = 0, unitCount = 0, decoyArms = 0;

function skipSemis() { while (isOp(p,';')) p++; }

function isGuardStart(i) { // `if a <= <numexpr> then ;`
  if (!(isKw(i,'if') && isName(i+1,'a') && isOp(i+2,'<='))) return false;
  try { const [, j] = parseNumExpr(i+3); return isKw(j,'then'); } catch { return false; }
}
function isStubAt(i) { // `if a<=E then ; end ;`
  if (!isGuardStart(i)) return false;
  try {
    const [, j] = parseNumExpr(i+3);
    let k = j+1; while (isOp(k,';')) k++;
    return isKw(k,'end');
  } catch { return false; }
}
function parseTransitionAt(i) { // `a = (a==a) and E1 or E2 ;` -> [next, idxAfter] | null
  if (!(isName(i,'a') && isOp(i+1,'=') && isOp(i+2,'(') && isName(i+3,'a') && isOp(i+4,'==') && isName(i+5,'a') && isOp(i+6,')') && isKw(i+7,'and'))) return null;
  try {
    const [e1, j] = parseNumExpr(i+8);
    if (!isKw(j,'or')) return null;
    const [e2, k] = parseNumExpr(j+1);
    if (!isOp(k,';')) return null;
    // `(a==a) and X or Y`: a==a is always true and X is a truthy number,
    // so the `or` arm is a never-taken decoy. Take e1.
    if (e1 !== e2) decoyArms++;
    return [e1, k+1];
  } catch (e) { if (String(e.message).startsWith('transition arms differ')) throw e; return null; }
}

// then-part content: stubs* then (nested unit | leaf soup)
// unit := 'if a<=' B 'then' THEN ['else' ELSE] 'end'  — else is OPTIONAL
// returns {type:'unit', B, then, else} or {type:'leaf', fragStart, fragEnd, next}
function parseTree(lo, hi) {
  if (!(isKw(p,'if') && isName(p+1,'a') && isOp(p+2,'<='))) throw new Error('expected guard @'+toks[p]?.s);
  const [B, afterB] = parseNumExpr(p+3);
  p = afterB;
  if (!isKw(p,'then')) throw new Error('then expected @'+toks[p].s);
  p++; skipSemis();
  unitCount++;
  const node = { type: 'unit', B, then: null, else: null, tokIdx: p };
  // THEN branch
  if (isGuardStart(p)) {
    node.then = parseTree(lo, B); // nested unit — self-contained (own else/end)
  } else {
    // leaf soup until transition (junk stubs stay in the soup; stripped post-assembly)
    const fragStart = p;
    let tr = null, q = p;
    while (q < N) {
      tr = parseTransitionAt(q);
      if (tr) break;
      q++;
    }
    if (!tr) {
      console.error('--- leaf soup without transition @' + toks[fragStart].s + ': ' + JSON.stringify(src.slice(toks[fragStart].s, toks[fragStart].s+120)));
      throw new Error('transition not found after leaf soup');
    }
    const fragEnd = q;
    p = tr[1]; skipSemis();
    node.then = { type: 'leaf', fragStart, fragEnd, next: tr[0], bound: B };
    leaves.push(node.then);
  }
  // optional ELSE branch
  if (isKw(p,'else')) {
    p++; skipSemis();
    if (isKw(p,'return')) {
      while (p < N && !isKw(p,'end')) p++; // stop AT the unit's closing 'end'
    } else {
      node.else = parseTree(B, hi);
    }
  }
  if (!isKw(p,'end')) {
    console.error(`--- END-EXPECT FAIL: B=${B} lo=${lo} hi=${hi} off=${toks[p]?.s} next5=${JSON.stringify(toks.slice(p,p+5).map(t=>t.v))}`);
    console.error('    ctx: ' + JSON.stringify(src.slice((toks[p]?.s??0)-160, (toks[p]?.s??0)+80)));
    throw new Error('end expected @'+toks[p]?.s+' after unit bound='+B);
  }
  p++; skipSemis();
  return node;
}

const rootHi = Infinity;
const root = parseTree(-Infinity, rootHi);

// ---- stub-unit collapse ----
// A junk stub parses as: unit(B2){ then: leaf(frag == "end"-only), else: none }.
// The real leaf is the OUTER one: its soup includes the whole `if a<=B2 then ; end ;`
// and the transition belongs to the outer state. Collapse so ranges/text are right.
function fragText(l) { return src.slice(toks[l.fragStart].s, toks[l.fragEnd - 1].e); }
let mergedStubs = 0;
(function mergeStubs(n) {
  if (!n || n.type !== 'unit') return;
  if (n.then && n.then.type === 'unit' && n.then.else === null &&
      n.then.then && n.then.then.type === 'leaf' &&
      /^[\s;]*end[\s;]*$/.test(fragText(n.then.then))) {
    const stub = n.then;
    stub.then.fragStart = stub.tokIdx; // absorb the stub guard into the fragment
    n.then = stub.then;
    mergedStubs++;
  }
  mergeStubs(n.then); mergeStubs(n.else);
})(root);
// rebuild leaves list after merge
leaves.length = 0;
(function collectLeaves(n) {
  if (!n) return;
  if (n.type === 'leaf') { leaves.push(n); return; }
  collectLeaves(n.then); collectLeaves(n.else);
})(root);
console.log(`merged ${mergedStubs} stub-units; leaves now ${leaves.length}`);
// close: end (while) end (function) end (m) , } )
skipSemis();
const expect = (cond, what) => { if (!cond) throw new Error('trailer mismatch: '+what+' @'+(toks[p]?.s??p)+' got '+JSON.stringify(toks.slice(p,p+3).map(t=>t?.v))); };
expect(isKw(p,'end'), 'while end'); p++; skipSemis();
expect(isKw(p,'end'), 'function end'); p++; skipSemis();
expect(isKw(p,'end'), 'm end'); p++; skipSemis();
expect(isOp(p,','), 'comma'); p++; skipSemis();
expect(isOp(p,'}'), 'brace'); p++; skipSemis();
expect(isOp(p,')'), 'paren'); p++;

console.log(`parsed: units=${unitCount} leaves=${leaves.length} stubs=${stubCount} decoy_or_arms=${decoyArms} initial_state=${a0}`);

// ---------------- interval index ----------------
// runtime-exact lookup: descend the tree exactly like `if a<=B`
function findLeaf(state) {
  let n = root;
  let depth = 0;
  const path = [];
  while (n && n.type === 'unit') {
    if (depth++ > 10000) return null;
    path.push(n.B + (state <= n.B ? 'T' : 'E'));
    n = state <= n.B ? n.then : n.else;
  }
  if (process.env.DEBUG_LEAF) {
    console.error('descent of', state, ':', path.join(' '));
    let d = root;
    for (const step of path) {
      if (!d || d.type !== 'unit') break;
      const off = toks[d.tokIdx].s;
      console.error(`  unit B=${d.B} @${off}: ` + JSON.stringify(src.slice(off, off + 90)));
      d = state <= d.B ? d.then : d.else;
    }
  }
  return n && n.type === 'leaf' ? n : null; // null = halt (else-branch empty / return)
}

// ---------------- state coverage analysis ----------------
const stateSet = new Set([a0, ...leaves.map(l => l.next)]);
const stateLeaf = new Map(); // state -> leaf (only when descent finds one)
let holes = [];
for (const s of stateSet) {
  const l = findLeaf(s);
  if (l) stateLeaf.set(s, l); else holes.push(s);
}
console.log(`runtime descent: states=${stateSet.size} mapped=${stateLeaf.size} holes=${holes.length} (broken dispatcher)`);

// The dispatcher tree's bound VALUES are corrupt (encoder collisions), but the tree
// TOPOLOGY is intact: each leaf's position implies the interval of states it serves.
// Recover intended state->leaf mapping by interval narrowing with sane bounds only,
// then constraint propagation (unique candidate <-> unique leaf).
const stateList = [...stateSet]; // 898 states (a0 + all nexts)
function rangeStates(lo, hi) { return stateList.filter(s => lo < s && s <= hi); }

// attach candidate sets to leaves via tree walk
(function annotate(n, lo, hi) {
  if (!n || n.type !== 'unit') return;
  // a bound is SANE for narrowing only if strictly inside the current interval
  const bThen = (lo < n.B && n.B <= hi) ? n.B : hi;   // then-side upper edge
  const bElse = (lo < n.B && n.B <= hi) ? n.B : lo;   // else-side lower edge
  if (n.then) annotate(n.then, lo, bThen);
  if (n.else) annotate(n.else, bElse, hi);
})(root, -Infinity, Infinity);
// leaves need their own ranges: redo pass storing them
const leafRange = new Map();
(function annotate2(n, lo, hi) {
  if (!n) return;
  if (n.type === 'leaf') { leafRange.set(n, [lo, hi]); return; }
  const sane = lo < n.B && n.B <= hi;
  annotate2(n.then, lo, sane ? n.B : hi);
  annotate2(n.else, sane ? n.B : lo, hi);
})(root, -Infinity, Infinity);

const cand = new Map(); // leaf -> Set(states)
for (const l of leaves) {
  const [lo, hi] = leafRange.get(l);
  cand.set(l, new Set(rangeStates(lo, hi)));
}
const hist = {};
for (const l of leaves) hist[cand.get(l).size] = (hist[cand.get(l).size] ?? 0) + 1;
console.log('candidates-per-leaf histogram:', JSON.stringify(hist));

// constraint propagation
const leafOf = new Map(); // state -> leaf
const stateOf = new Map(); // leaf -> state
let changed = true;
while (changed) {
  changed = false;
  // drop states already assigned elsewhere
  for (const l of leaves) {
    const cs = cand.get(l);
    for (const s of cs) if (leafOf.has(s) && leafOf.get(s) !== l) cs.delete(s);
    if (cs.size === 1) {
      const s = [...cs][0];
      if (!stateOf.has(l)) { stateOf.set(l, s); leafOf.set(s, l); changed = true; }
    }
  }
  for (const s of stateList) {
    if (leafOf.has(s)) continue;
    const cands = leaves.filter(l => cand.get(l).has(s));
    if (cands.length === 1) {
      leafOf.set(s, cands[0]); stateOf.set(cands[0], s); changed = true;
    }
  }
}
const unresolvedLeaves = leaves.filter(l => !stateOf.has(l));
const unresolvedStates = stateList.filter(s => !leafOf.has(s));
if (process.env.DEBUG_LEAF) {
  // locate the cycle: first-visit index of each state on the walk
  const seenAt = new Map();
  let s = a0, i = 0;
  while (i < 3000) {
    if (seenAt.has(s)) { console.error(`cycle: state ${s} first at step ${seenAt.get(s)}, again at step ${i}`); break; }
    seenAt.set(s, i);
    const l = leafOf.get(s);
    if (!l) { console.error(`chain broke at state ${s} step ${i}`); break; }
    s = l.next; i++;
  }
  for (const l of unresolvedLeaves) {
    const [lo, hi] = leafRange.get(l);
    console.error(`  unresolved leaf next=${l.next} range=(${lo},${hi}] cands=[${[...cand.get(l)]}] frag=${JSON.stringify(fragText(l).slice(0,60))}`);
  }
}
console.log(`propagation: resolved ${stateOf.size}/${leaves.length} leaves, ${leafOf.size}/${stateList.length} states; unresolved leaves=${unresolvedLeaves.length} states=${unresolvedStates.length}`);
if (process.env.DEBUG_LEAF) {
  for (const l of unresolvedLeaves) {
    const [lo, hi] = leafRange.get(l);
    const frag = src.slice(toks[l.fragStart].s, toks[l.fragEnd - 1].e);
    console.error(`  unresolved leaf next=${l.next} range=(${lo},${hi}] states_in_range=[${rangeStates(lo,hi)}] frag=${JSON.stringify(frag.slice(0, 70))}`);
  }
  console.error('unresolved states:', unresolvedStates.join(','));
  const who167 = leaves.filter(l => l.next === 167);
  console.error('leaves with next==167:', who167.map(l => JSON.stringify(src.slice(toks[l.fragStart].s, toks[l.fragEnd-1].e).slice(0,60))).join(' | '));
  const stubLeaf = leaves.find(l => { const [lo,hi]=leafRange.get(l); return hi===167; });
  if (stubLeaf) console.error('leaf with range-hi 167:', JSON.stringify(src.slice(toks[stubLeaf.fragStart].s, toks[stubLeaf.fragEnd-1].e).slice(0,80)), 'assigned_state=', stateOf.get(stubLeaf));
}

// fragment helpers: net bracket/block depth (syntax oracle) + text output
const deltaCache = new Map();
function fragDelta(l) {
  if (deltaCache.has(l)) return deltaCache.get(l);
  const text = src.slice(toks[l.fragStart].s, toks[l.fragEnd - 1].e);
  let p = 0, br = 0, sq = 0, k = 0;
  for (const t of tokenize(text)) {
    if (t.t !== 'kw' && t.t !== 'op') continue;
    if (t.v === '(') p++;
    else if (t.v === ')') p--;
    else if (t.v === '{') br++;
    else if (t.v === '}') br--;
    else if (t.v === '[') sq++;
    else if (t.v === ']') sq--;
    else if (t.t === 'kw' && (t.v === 'function' || t.v === 'if' || t.v === 'do' || t.v === 'repeat')) k++;
    else if (t.t === 'kw' && (t.v === 'end' || t.v === 'until')) k--;
  }
  const d = [p, br, sq, k];
  deltaCache.set(l, d);
  return d;
}
const stripStubRe = /if a<=(?:0[bB][01_]+|0[xX][0-9a-fA-F_]+|\d[\d_]*(?:\+\d[\d_]*)?)\s*then\s*;\s*end\s*;?/g;
function leafOutText(l) {
  return src.slice(toks[l.fragStart].s, toks[l.fragEnd - 1].e).replace(stripStubRe, '');
}

// ---------------- emulate: exact DFS over raw-range candidates ----------------
// candidates from PRISTINE ranges (pre-propagation); the machine is a lasso:
// a path from a0 that may close into a cycle. Accept long balanced completions.
const rawCand = new Map(); // state -> [leaves whose raw range contains it]
for (const l of leaves) {
  for (const s of rangeStates(...leafRange.get(l))) {
    if (!rawCand.has(s)) rawCand.set(s, []);
    rawCand.get(s).push(l);
  }
}
// order each state's candidates: propagation-resolved first, then by range tightness
for (const [s, arr] of rawCand) {
  arr.sort((a, b) => {
    const ra = leafOf.get(s) === a ? -1 : 0;
    const rb = leafOf.get(s) === b ? -1 : 0;
    return ra - rb;
  });
}
let dfsNodes2 = 0;
let bestChain = null; // {order, depth, kind}
function candList(s) {
  const base = [...(rawCand.get(s) ?? [])];
  const soft = leafOf.get(s);
  if (soft && !base.includes(soft)) base.unshift(soft);
  // nearest-range free leaves as last resort
  const extra = leaves
    .filter(l => !base.includes(l))
    .map(l => {
      const [lo, hi] = leafRange.get(l);
      let d2;
      if (lo < s && s <= hi) d2 = 0;
      else if (s <= lo) d2 = lo - s;
      else d2 = s - hi;
      return [l, d2];
    })
    .sort((a, b) => a[1] - b[1])
    .filter(x => x[1] <= 3000)
    .slice(0, 4)
    .map(x => x[0]);
  return base.concat(extra);
}
function exactWalk() {
  const order = [];
  const usedLeaves = new Set();
  const seenStates = new Map(); // state -> step
  const depth = [0, 0, 0, 0];
  function step(s, d) {
    if (dfsNodes2++ > 8000000) return 'budget';
    if (seenStates.has(s)) {
      // lasso closure: accept if long and balanced
      if (order.length >= 840 && depth.every(v => v === 0)) {
        bestChain = { order: [...order], kind: 'cycle@' + s + '/len' + order.length };
        return 'accept';
      }
      return null;
    }
    const cands = candList(s);
    let triedAny = false;
    for (const c of cands) {
      if (usedLeaves.has(c)) continue;
      const dd = fragDelta(c);
      if (depth.some((v, i) => v + dd[i] < 0)) continue;
      // statement-level validity: at zero depth a fragment may not start with a
      // list separator/closer nor end with a comma — such gluing is invalid Lua
      if (depth[0] === 0 && depth[1] === 0 && depth[3] === 0) {
        const txt = leafOutText(c).trim();
        const first = txt[0];
        if (first === ',' || first === ')' || first === '}') continue;
        const nd2 = [depth[0]+dd[0], depth[1]+dd[1], depth[2]+dd[2], depth[3]+dd[3]];
        if (nd2[0] === 0 && nd2[1] === 0 && nd2[3] === 0 && /,\s*$/.test(txt)) continue;
      }
      triedAny = true;
      usedLeaves.add(c); order.push(c); seenStates.set(s, order.length - 1);
      const nd = [depth[0]+dd[0], depth[1]+dd[1], depth[2]+dd[2], depth[3]+dd[3]];
      const pd = [...depth];
      depth[0]=nd[0]; depth[1]=nd[1]; depth[2]=nd[2]; depth[3]=nd[3];
      const r = step(c.next, d + 1);
      if (r === 'accept' || r === 'budget') { seenStates.delete(s); return r; }
      depth[0]=pd[0]; depth[1]=pd[1]; depth[2]=pd[2]; depth[3]=pd[3];
      order.pop(); usedLeaves.delete(c); seenStates.delete(s);
      // track best-so-far even when dead-ending
      if (!bestChain || order.length > bestChain.order.length) bestChain = { order: [...order], kind: 'partial/len' + order.length };
    }
    if (!triedAny && order.length >= 840 && depth.every(v => v === 0)) {
      bestChain = { order: [...order], kind: 'break@' + s + '/len' + order.length };
      return 'accept';
    }
    return null;
  }
  const r = step(a0, 0);
  return r;
}
// persist/reuse the solved chain so formatting iterations don't re-run the DFS
const CHAIN_FILE = 'chain.json';
if (process.env.SKIP_DFS && fs.existsSync(CHAIN_FILE)) {
  const saved = JSON.parse(fs.readFileSync(CHAIN_FILE, 'utf8'));
  const byKey = new Map(leaves.map(l => [`${l.fragStart}:${l.fragEnd}:${l.next}`, l]));
  const restored = saved.order.map(k => byKey.get(k)).filter(Boolean);
  if (restored.length === saved.order.length) {
    bestChain = { order: restored, kind: saved.kind + ' (cached)' };
    console.log(`chain restored from ${CHAIN_FILE}: ${restored.length} leaves`);
  } else exactWalk();
} else exactWalk();
if (bestChain && !process.env.SKIP_DFS) {
  fs.writeFileSync(CHAIN_FILE, JSON.stringify({ kind: bestChain.kind, order: bestChain.order.map(l => `${l.fragStart}:${l.fragEnd}:${l.next}`) }));
}
const chainLeaves = bestChain ? bestChain.order : [];
const endKind = bestChain ? bestChain.kind : 'none';
const visited = new Set(chainLeaves);
// strip the obfuscator's artifact `;` after fragments that end mid-construction
function leafText(l) {
  let t = leafOutText(l);
  const d = fragDelta(l);
  if (d[0] !== 0 || d[1] !== 0 || d[2] !== 0 || d[3] !== 0) t = t.replace(/[\s;]+$/, '');
  return t;
}
const frags = [];
for (const l of chainLeaves) frags.push(leafText(l));
const steps = chainLeaves.length;
console.log(`emulated: steps=${steps} end=${endKind} final dfs_nodes=${dfsNodes2} unused_leaves=${leaves.length - visited.size}`);
if (process.env.DEBUG_LEAF || true) {
  const termState = chainLeaves.length ? chainLeaves[chainLeaves.length - 1].next : null;
  console.log(`terminal state: ${termState}`);
  const unused = leaves.filter(l => !visited.has(l));
  console.log(`unused leaves: ${unused.length}`);
  for (const u of unused.slice(0, 45)) {
    const [lo, hi] = leafRange.get(u);
    console.log(`  next=${u.next} range=(${lo},${hi}] dist=${(lo<termState&&termState<=hi)?0:(termState<=lo?lo-termState:termState-hi)} frag=${JSON.stringify(fragText(u).slice(0,60))}`);
  }
}

// ---------------- assemble ----------------
// append leftover leaves (ambiguous order due to the obfuscator's corrupt
// dispatcher) in their own clearly-marked section, chained among themselves
// where next-links allow.
const unusedLeaves = leaves.filter(l => !visited.has(l));
const leftover = [];
{
  const stillUnused = new Set(unusedLeaves);
  const nextOf = new Map(); // state -> unused leaf serving it (by range bound)
  for (const l of unusedLeaves) nextOf.set(leafRange.get(l)[1], l);
  while (stillUnused.size) {
    let cur = [...stillUnused][0];
    for (let guard = 0; guard < 100; guard++) {
      const pred = nextOf.get(leafRange.get(cur)[1] ? guessPrev(cur) : undefined);
      if (pred && stillUnused.has(pred)) cur = pred; else break;
    }
    for (let guard = 0; guard < 1000 && cur; guard++) {
      leftover.push(cur); stillUnused.delete(cur);
      const myState = leafRange.get(cur)[1];
      const nxt = nextOf.get(cur.next);
      cur = (nxt && stillUnused.has(nxt)) ? nxt : null;
      void myState;
    }
  }
}
function guessPrev() { return undefined; }
const header = `-- NZL Studio Obfuscator — статическая деобфускация (NZLDeobf/deobf.mjs)
-- ВНИМАНИЕ: обфусцированный оригинал (nzl_obf.lua) вообще не компилируется
-- (101 ошибка парсинга Luau) — обфускатор разрезал инструкции на синтаксически
-- невалидные фрагменты и повредил диспетчер (дублирующиеся границы состояний).
-- Ниже — восстановленный порядок фрагментов по переходам стейт-машины
-- (все переходы вычислены статически, рантайм не требуется).
-- states: entry=${a0}, chained=${steps}/${leaves.length}
`;
let out = header + frags.join('\n');
if (leftover.length) {
  out += `\n\n-- ======== ФРАГМЕНТЫ С НЕОДНОЗНАЧНЫМ ПОРЯДКОМ (${leftover.length} шт.) ========\n-- Диспетчер обфускатора повреждён (коллизии bxor-кодера границ), поэтому точное\n-- место этих фрагментов в цепочке статически не восстановимо. Фрагменты сцеплены\n-- по их собственным next-переходам.\n`;
  out += leftover.map(l => leafText(l)).join('\n');
}
fs.writeFileSync(OUT_FILE, out);
console.log(`wrote ${OUT_FILE}: ${frags.length}+${leftover.length} fragments, ${out.length} bytes`);

// stats for report
const fragChars = frags.reduce((a, f) => a + f.length, 0);
console.log(`avg frag len: ${(fragChars / frags.length).toFixed(1)} chars`);
