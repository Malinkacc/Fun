const KEYWORDS = new Set(['and','break','do','else','elseif','end','false','for','function','if','in','local','nil','not','or','repeat','return','then','true','until','while','continue','export','type']);

function tokenize(s) {
  const toks = []; // {t:'kw'|'name'|'num'|'str'|'op', v, s, e}
  let i = 0, n = s.length;
  const push = (t, v, st) => toks.push({ t, v, s: st, e: i });
  while (i < n) {
    const c = s[i];
    if (c === ' ' || c === '\t' || c === '\r' || c === '\n') { i++; continue; }
    // comments
    if (c === '-' && s[i+1] === '-') {
      const st = i; i += 2;
      const m = /^\[(=*)\[/.exec(s.slice(i));
      if (m) { const close = ']' + m[1] + ']'; const j = s.indexOf(close, i + m[0].length); i = (j < 0 ? n : j + close.length); }
      else { let j = s.indexOf('\n', i); if (j < 0) j = n; i = j; }
      push('comment', s.slice(st, i), st); continue;
    }
    // long strings
    if (c === '[') {
      const m = /^\[(=*)\[/.exec(s.slice(i));
      if (m) { const st = i; const close = ']' + m[1] + ']'; const body = i + m[0].length;
        const j = s.indexOf(close, body); i = (j < 0 ? n : j + close.length);
        push('str', s.slice(st, i), st); continue; }
    }
    if (c === '"' || c === "'" || c === '`') {
      const st = i; const q = c; i++;
      while (i < n) {
        if (s[i] === '\\') { i += 2; continue; }
        if (s[i] === q) { i++; break; }
        i++;
      }
      push('str', s.slice(st, i), st); continue;
    }
    if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(s[i+1] ?? ''))) {
      const st = i;
      const m = /^(0[xX][0-9a-fA-F_]+|0[bB][01_]+|(?:\d[\d_]*)?\.?\d[\d_]*(?:[eE][+-]?\d+)?)/.exec(s.slice(i));
      i += m[0].length;
      push('num', m[0], st); continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      const st = i; const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i)); i += m[0].length;
      push(KEYWORDS.has(m[0]) ? 'kw' : 'name', m[0], st); continue;
    }
    // operators, longest first
    const ops = ['...','..=','..','::','+=','-=','*=','/=','^=','%=','==','~=','<=','>=','+','-','*','/','%','^','#','~','=','<','>','(',')','{','}','[',']',';',':',',','.'];
    let matched = null;
    for (const op of ops) if (s.startsWith(op, i)) { matched = op; break; }
    if (!matched) throw new Error(`tokenizer stuck at ${i}: ${JSON.stringify(s.slice(i, i+20))}`);
    const st = i; i += matched.length; push('op', matched, st); continue;
  }
  return toks;
}


export { tokenize, KEYWORDS };
